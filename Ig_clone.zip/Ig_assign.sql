use ig_clone;
-- We want to reward the user who has been around the longest, Find the 5 oldest users.
select * from users 
order by created_at
limit 5;
 
 -- 3.To target inactive users in an email ad campaign, find the users who have never posted a photo.
select username from users
left join photos on users.id=photos.user_id
where photos.id is null;
 
 -- 4.Suppose you are running a contest to find out who got the most likes on a photo. Find out who won?
 select users.username, photos.id,photos.image_url,count(*) as total_likes
from likes
join photos on photos.id=likes.photo_id
join users on users.id=likes.photo_id
group by photos.id
order by total_likes desc;

-- 5.The investors want to know how many times does the average user post

select(select COUNT(*)FROM photos)/(SELECT COUNT(*) FROM users) as avg;

-- 6.A brand wants to know which hashtag to use on a post, and find the top 5 most used hashtags.
select t.tag_name, count(*) as total
from photo_tags pt join tags t
on pt.tag_id=t.id
group by t.id
order by total desc
limit 5;

-- 7.To find out if there are bots, find users who have liked every single photo on the site.
 select u.username,
    COUNT(*) as total_user_likes
from users u
    join likes
        on u.id = likes.user_id
    group by u.id
    having total_user_likes = (select COUNT(*) from photos);
    
    -- 8.Find the users who have created instagramid in may and select top 5 newest joinees from it?
    select * from users
    where monthname(created_at)='May'
    order by created_at desc limit 5;
     
     -- 9.Can you help me find the users whose name starts with c and ends with any number and
     -- have posted the photos as well as liked the photos?
    
    select u.username,u.id,count(u.id) as num_likes from
    users u join photos p on u.id=p.user_id
    join likes on u.id=likes.user_id
    group by u.id
    having u.username like 'c%' and u.username regexp'[0-9]$' 
    order by num_likes;
    
    
     -- 10.Demonstrate the top 30 usernames to the company who have posted photos in the range of 3 to 5.
        with top_users as (select u.username,u.id,count(u.id) as posted_photos from users u
        join photos p on u.id=p.user_id group by u.id)
        select * from top_users where posted_photos between 3 and 5 limit 30;
	